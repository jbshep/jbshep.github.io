## This is all implemented in the main.py file.
import json
import requests

import kivy
kivy.require('1.9.0')

from kivy.app import App
from kivy.properties import ObjectProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.listview import ListItemButton

class NamesButton(ListItemButton):
    pass

class SearchNamesForm(BoxLayout):

    people = (requests.get("http://localhost:3000/api/burial-summary"))
    people = people.json()

    search_input = ObjectProperty()
    search_results = ObjectProperty()

    def search_names(self):
        newlist = []
        for person in self.people:
            if self.search_input.text == person["last_name"]:
                newlist.append(person)        
        
        personList = list(map(lambda person: ""+person["first_name"]+" "+person["last_name"]+" "+person["birth_date"]+" "+person["death_date"],newlist)) 
    
        self.search_results.item_strings = personList 
        del self.search_results.adapter.data[:]
        self.search_results.adapter.data.extend(personList) 
        self.search_results._trigger_reset_populate()

class NameSearchApp(App):
    pass


if __name__ == '__main__':

    NameSearchApp().run()
