import json
import requests

import kivy
import sys
kivy.require('1.9.0')

from kivy.app import App
from kivy.properties import ObjectProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.listview import ListView, ListItemButton
from kivy.adapters.listadapter import ListAdapter
#from kivy.lang import Builder
#from pyler.platforms.android.camera import AndroidCamera
#
## This is the camera part of the app that has not been implemented yet.
#
#
#class MyCamera(AndroidCamera):
#	pass
#
## This is the layout for the camera
#class BoxLayoutW(BoxLayout):
#	my_camera = ObjectProperty(None)
#	image_path = StringProperty('test_photo.png')
#
#	def __init__(self, **kwargs):
#		super(BoxLayoutW, self).__init__()
#		self.my_camera = MyCamera()
#
## This is to take a picture
#	def take_shot(self):
#		self.my_camera._take_picture(self.on_success_shot, self.image_path)
#
## This is save the picture
#	def on_success_shot(self):
#		image_str = self.image_conver_base64
#		return True
#
#
#	def image_conver_base64(self):
#		with open(self.image_path, "rb") as image_file:
#			encoded_string = baste64.b64encode(image_file.read())
#		if not encoded_string:
#			encoded_string = ''
#		return encoded_string
## This is the layout for the user interface
class SearchNamesForm(BoxLayout):    
    ## Gets the burial list from the website
    people = (requests.get("http://127.0.0.1:3000/api/burial-summary"))
    people = people.json()

    search_input = ObjectProperty()
    search_results = ObjectProperty()

    firstNameLabel = ObjectProperty()
    lastNameLabel = ObjectProperty()
    deathDateLabel = ObjectProperty()
    birthDateLabel = ObjectProperty()
    
    searched_list = []
    
    ## After a name is selected this displays all info for that person at the bottom of the screen
    def clear_labels(self):
    
        self.firstNameLabel.text = "" 
        self.lastNameLabel.text = ""
        self.birthDateLabel.text = ""
        self.deathDateLabel.text = ""

    def detail_view_update(self, adapter):
        self.clear_labels()       

        if len(adapter.selection) != 0:
            selected_person = adapter.selection[0].index

            self.firstNameLabel.text = self.searched_list[selected_person]["first_name"]
            self.lastNameLabel.text = self.searched_list[selected_person]["last_name"]
            self.birthDateLabel.text = self.searched_list[selected_person]["birth_date"]
            self.deathDateLabel.text = self.searched_list[selected_person]["death_date"]
    ## searches through the list of people to find the last name that is entered
    ## and makes a new list of people with that last name.
    def search_names(self):
        self.clear_labels();
        self.searched_list = []
        for person in self.people:
            if self.search_input.text == person["last_name"]:
                self.searched_list.append(person)
        
        list_item_args_converter = lambda row_index, person: {'text': person["first_name"], 'size_hint_y': None, 'height': 30}

        list_adapter = ListAdapter(data = self.searched_list, args_converter = list_item_args_converter, cls = ListItemButton)
        
        self.search_results.adapter = list_adapter 
        list_adapter.bind(on_selection_change = self.detail_view_update)

class NameSearchApp(App):
    pass


if __name__ == '__main__':

    NameSearchApp().run()
