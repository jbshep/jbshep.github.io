#Cam-Gamma Camera App


##What Is This?

This software is being developed for Android for a local cemetery so that they can map burial sites to gps coordinates to make finding grave sites of family members much easier.  Along with the gps locations for each grave site they will also be able to add a picture of the headstone to make finding the gravesite easier as well.  The app will relay this information to a database that is being used for the cemetery's website.

The app uses
* [Kivy] - Python library for Android
* [Plyer] - API to access Android hardware


##Installation and use

To be able to run this app we need to first setup a couple of backend things.
* The database that we will be posting our pictures to.
* Kivy which is the language that the app is written in.
* Buildozer and Kivy Launcher which are 2 different ways to launch apps onto a phone. 

###Database setup

Instructions for how to set up a database can be found in the [Sl-Cem] web app.


###App setup
Our app is written using kivy which is an open source, cross-platfrom [Python] framework for the development of applications. Kivy is written using [Python] and [Cython]. Complete installations instructions can be found at the [Kivy docs]. This includes installation of kivy itself and all of its dependancies such as Cython. Note that you will have to have both the Java [JDK] and [JRE] installed to be able to test the app.


##Packaging using Buildozer

**[Buildozer] currently only works with Python 2. Python 3 has not yet been supported for Buildozer.**

Installation instructions can be found at the [Buildozer] README file. The README file also has instructions on how buildozer works and how to build the APK file that is your app. Buildozer uses 32 bit libraries so you will have to install these extra libraries. 

###Setting Up the Phone

With android phones they are set to not trust apps from outside or unkown sources (basically other than the Google Play Store). To get around this the phone needs to be changed into developer mode. Information on how to do this can be found [here].

##Packaging using Kivy Launcher

We used kivy launcher testing purposes. Information on how to use the kivy launcher can be found at the [Kivy docs]. Its as simple as downloading the Kivy Launcher app and creating a folder for you apps to store in.


[GitHub]: <https://github.com>
[Sl-Cem]: <https://github.com/jbshep/sl-cem>
[Kivy]: <https://kivy.org>
[Plyer]: <https://github.com/kivy/plyer>
[Cython]: <https://cython.org>
[Kivy docs]: <kivy.org/docs/installations/installation.html>
[JDK]: <www.oracle.com/technetwork/java/javase/downloads/index.html>
[JRE]: <www.oracle.com/technetwork/java/javase/downloads/index.html>
[Buildozer]: <https://github.com/kivy/buildozer>
[here]: <developer.android.com/tools/device.html>
