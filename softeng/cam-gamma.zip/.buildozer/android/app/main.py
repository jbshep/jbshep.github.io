__version__ = "1.2.0"

import sys

sys.path.append("home/gamabunta/projects/software/CameraApp/cam-gamma/plyer/plyer/platforms/android")

import kivy

from plyer.platforms.android.camera import AndroidCamera

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import ObjectProperty, StringProperty

import base64

class MyCamera(AndroidCamera):
	pass

class BoxLayoutW(BoxLayout):
	my_camera = ObjectProperty(None)

	image_path = StringProperty('/sdcard/test_phot0.png')

	def __init__(self, **kwargs):
		super(BoxLayoutW, self).__init__()
		self.my_camera = MyCamera()

	def take_shot(self):
		self.my_camera._take_picture(self.on_success_shot, self.image_path)

	def on_success_shot(self):
		image_str = self.image_convert_base64
		return True

	def image_conver_base64(self):
		with open(self.image_path, "rb") as image_file:
			encoded_string = baste64.b64encode(image_file.read())
		if not encoded_string:
			encoded_string = ''
		return encoded_string

if __name__ == '__main__':

	class CameraApp(App):
		def build(self):
			main_window = BoxLayoutW()
			return main_window

	CameraApp().run()
