from django.conf.urls import url
from django.contrib.auth import views
#from django.views.generic.edit import CreateView
#from django.contrib.auth.forms import UserCreationForm

from . import views

urlpatterns = [
	url(r'^$', views.goto, {'whereto': 'index'}, name='index'),
	url(r'^newuser/$', views.goto,  {'whereto': 'newuser'}, name='newuser'),	
	url(r'^mygames/$', views.goto,  {'whereto': 'mygames'}, name='mygames'),
	url(r'^game/(?P<gamename>[-\w]+)/$', views.goto,  {'whereto': 'gamepage'}, name='gamepage'),
	url(r'^login/$', views.goto, {'whereto': 'mylogin'},  name='login'),
	url(r'^home/$', views.goto, {'whereto': 'home'},  name='home'),
	url(r'^games/$', views.goto, {'whereto': 'games'},  name='games'),
	url(r'^creategame/$', views.goto, {'whereto': 'create_game_form'},  name='create_game_form'),
	url(r'^mygames/$', views.goto, {'whereto': 'mygames'}, name='mygames'),
	url(r'^reporttag/$', views.goto, {'whereto': 'reporttag'}, name='reporttag'),
	url(r'^warning/$', views.warning,  name='Something went wrong'),
	#url(r'^.*', views.warning, name='Something went wrong')
]
