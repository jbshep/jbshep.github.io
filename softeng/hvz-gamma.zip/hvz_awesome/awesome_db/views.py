from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.shortcuts import render_to_response
from django.template import RequestContext, loader, Template, Context, engines
from django.template.loader import render_to_string
from django.utils.html import escape
from django.core.urlresolvers import reverse
from .forms import UserForm, GameForm
from .models import Game, Mod, Player, PlayerType
from django.views.decorators.csrf import csrf_exempt
import datetime

def renderpage(request, page,form,context, gamename =None):
	conT = loader.get_template('awesome_db/'+page+'.html')
	content = conT.render(Context({
		'request':request,
		'form':form,
		'content':context}))
	return render(request,'awesome_db/template.html',{'content':content,'gamename':gamename})

#INDEX: The view that is accessed by default. (Creates a login form)
def index(request):#SHOULD NOT BE HIT.
	#Set the var 'form' to be of type 'UserForm' from .forms 
	form = UserForm()
	#Render the opento template, and structure the form with type from the var 'form'
	return renderpage(request,'login',form,None)
	#return render(request, 'awesome_db/opento.html', {'form':form})

#HOME: Go to the main home page
def home(request):
	return renderpage(request,'home',None,None)
	#return render(request, 'awesome_db/home.html')

def gamepage(request, gamename):
	#if request.method == "POST":
		#gameid = request.POST.get('GameId')
	if(gamename is not None):
		query = Game.objects.filter(Name=gamename)
		if (query[0]):
			gameid = query[0].id
			playerquery= Player.objects.filter(GameId=gameid, UserId=request.user.id)
			if(playerquery[0]):
				playertypequery=PlayerType.objects.filter(GameId=gameid, id=playerquery[0].PlayerTypeId.id)
				if(playertypequery[0]):
					team = "HUMAN"
					#Run a count query to replace human count and zombie count.
					if(playertypequery[0].TeamId != 1):
						team = "ZOMBIE"
					info=Context({
						'gameid':gameid,
						'gamename':query[0].Name,
						'humancount':12,
						'zombiecount':13,
						'playerteam':team
					})
					return renderpage(request,'gamepage',None,info,gamename)
	return redirect('/awesome_db/warning')	

@csrf_exempt
def goto(request,whereto,gamename = None):
	if(request.user.is_authenticated()):
		print("user is authenticated.")
	else:
		print("user is NOT authenticated.")
	print("Path: "+request.path)
	print("Goto: "+whereto)
	if(whereto == "index" or whereto == "mylogin"):
		if(request.user.is_authenticated()):
			return HttpResponseRedirect("/awesome_db/home/")
		return mylogin(request)
	elif(whereto == "newuser"):
		return newuser(request)
	elif(request.user.is_authenticated() == False):
		return HttpResponseRedirect("/awesome_db/")
	elif(whereto == "home"):
		return home(request)
	elif(whereto == "games"):
		return games(request)
	elif(whereto == "mygames"):
		return mygames(request)
	elif(whereto == "create_game_form"):
		return create_game_form(request)
	elif(gamename is not None):
		if(whereto == "gamepage"):
			return gamepage(request,gamename)
	print("whereto did not match.")
	print("User:"+request.user.username)
	return redirect('/awesome_db/warning/')
	#return message(request,("Could not navigate to page "+whereto),"../home/")

#:GAMES Present Games and you are able to join any games that have been creted
@csrf_exempt
def games(request):
	if request.method == "POST":
		print("Games--Post")
		#Once the user has joined a game this will check which one they picked
		id = request.POST.get('Game')
		#when they first join their player status will be human
		query = PlayerType.objects.filter(GameId=id,TeamId=1)
		#They will only be able to see what the mods allow the humans to see
		narrow = query.filter(Name="Human")
		typeId = -1
		if(narrow[0]):
			typeId=narrow[0]
		elif(query[0]):
			typeId=query[0]
		#print("Type Id: "+typeId)
		#if(id != "Error" and typeId != -1 and !(Player.objects.filter(GameId=id, UserId = request.user)[0])):
		if(id != "Error" and typeId != -1):
			#updates the database on what game that player is a part of
			player = Player(GameId=Game.objects.filter(id=id)[0], UserId=request.user,PlayerTypeId=typeId)
			player.save()
			return message(request,("You successfully joined "+id),"/awesome_db/home/")
	else:
	#shows the page of the games able to be selected
		print("Games--NoPost")
		game_list = Game.objects.order_by('Name')
		context = {'game_list': game_list, 'Game': ""}
		return renderpage(request,'games',None,context)
		#return render(request, 'awesome_db/games.html', context)
	return message(request,("Something went horribly wrong."),"/awesome_db/home/")

def mygames(request):
	uid = request.user.id
	ps = Player.objects.filter(UserId = uid)
	game_list = []
	for p in ps:
		g = Game.objects.filter(id=p.GameId.id)
		if(g[0]):
			print(g[0].Name)
			game_list.append(g[0])
	context = {'game_list': game_list, 'Game': ""}
	return renderpage(request, 'mygames', None, context)

@csrf_exempt
def reporttag(request):
	print("in report_tag")
	#Get the game id and the currently logged in user's id
	game = request.POST.get('Game')
	uid = request.user.id

	if request.method == "POST":
		#Save the id of the person that is getting tagged
		pid = request.POST.get('pid')

		taggedPlayer = Player.objects.filter(UserId=pid)
		taggingPlayer = Player.objects.filter(UserId=uid)

		#Query to get the TeamId and Name
		q1 = PlayerType.objects.filter(GameId=game, TeamId=0)
		q2 = q1.filter(Name="Zombie")

		typeId = -1
		if(q2[0]):
			typeId=q2[0]
		elif(q1[0]):
			typeId=q1[0]

		if(typeId!=-1 and pid!=None):
			#Updates the database. Changed the TeamId and Name to be a zombie
			taggedPlayer = Player(GameId=Game.objects.filter(id=game)[0], UserId=pid, PlayerTypeId=typeId)
			taggedPlayer.save()
			pring("you tagged a player")

	return renderpage(request, 'reporttag', None, None)
	#return render(request, 'awesome_db/reporttag.html')

#MESSAGE: A message view, allowing you to specify a message to display to the user, and where the "Continue" button should take them
def message(request,msg,retTo):
	context = ({'msg':msg,'retTo':retTo})
	return renderpage(request,'message',None,context)

def warning(request):
	return(message(request,"Something went wrong. That page may not exist or an error has occured. please log back in.","/awesome_db/mylogin/"))

@csrf_exempt
def newuser(request):
	print("new user...")
	if request.method == "POST":
		form = UserForm(request.POST)
		print("checking for valid creation")
		if form.is_valid():
			print("CREATING A VALID FORM USER")
			new_user = User.objects.create_user(**form.cleaned_data)
			login(request,new_user)
			return HttpResponseRedirect("/awesome_db/home/")
			#Redirect to main page
			#return HttpResponse("Hello, world. you've arrived at HVZ AWESOME.")
	form = UserForm()
	return renderpage(request,'newuser',form,None)
	#return render(request, 'awesome_db/newuser.html')

#MYLOGIN: A view to allow existing users to login
@csrf_exempt
def mylogin(request):
	print("login hit.")
	if request.method == "POST":
		print("in login")
		form = UserForm(request.POST)
		#Gets the input the user puts in for their username and password
		username = request.POST.get('username')
		password = request.POST.get('password')
		#Changes user from None if the authentication is confirmed
		user = authenticate(username=username,password=password)
		print("attempted authenticate for "+username+","+password)
		if user is not None:
			print("here2")
			if user.is_active:
				#Logs the user in and returns to the home page
				login(request, user)
				print("returning normal")
				return HttpResponseRedirect("/awesome_db/home/")
				#return HttpResponse("Hello! You are signed in to HVZAWESOME!")	
			else:
				#Returns this message on the page if the user boolean "is_active" is set to false
				return HttpResponse("You are not an active user. see admin.")
	print("here3")
	form = UserForm()
	return renderpage(request,'login',form,None)
	#return render(request, 'awesome_db/login.html', {'form':form})

@csrf_exempt
def create_game_form(request):
	print("create a game hit.")
	#If statment is only true here on second pass of create_game_form once the post data has been sent from the form and html pages.
	if request.method=="POST":
		print("post request.")
		form = GameForm(request.POST)
		#If statement checks to see if the from has been filled and is valid.
		if form.is_valid():
			print("form is valid")
			#The next five lines pull the data from the form and place them in variables to be added to the model instance.
			game= request.POST.get('Name')
			location= request.POST.get('Location')
			rules= request.POST.get('Rules')
			#Note: start and end dates are formatted in DD/MM/YYYY format and need to be processed based on this.
			start= datetime.datetime.strptime(request.POST.get('StartDate'), '%m/%d/%Y').strftime('%Y-%m-%d')
			end = datetime.datetime.strptime(request.POST.get('EndDate'), '%m/%d/%Y').strftime('%Y-%m-%d')
			print("Name: "+game+". location: "+location+". rules: "+rules+". start: "+start+". end: "+end+".")
			# g is a declared instance of the model(in this case it is Game). g.save is what actually sends the data from the filled model to instance to the database.
			g=Game(Name=game,Location=location,StartDate=start,EndDate=end,Rules=rules, AlertMessage = "No alert message")
			g.save()
			#The game that is being created is automatically filled with the Mod with the next two lines the same as g. The user info is pulled from request.user(which is django data).
			mod=Mod(GameId=g,ModId=request.user)
			mod.save()
			defPlayerType = PlayerType(GameId=g,Name="Human",Description="The default human player class.", TeamId=1)
			defPlayerType.save()
			defZombieType = PlayerType(GameId=g,Name="Zombie",Description="The default zombie player class.",TeamId=2)
			defZombieType.save()
			return message(request,"Game created!","/awesome_db/home/")
		else:
			print("form is invalid.")
			return message(request,"Form was invalid.", "/awesome_db/creategame/")
		return renderpage(request,'creategame', form,None)
	else:
		print("No post request")
                #GameForm states the type form from forms.py that needs to be filled out later when it is passed through.
		form=GameForm()
		return renderpage(request,'creategame',form,None)
