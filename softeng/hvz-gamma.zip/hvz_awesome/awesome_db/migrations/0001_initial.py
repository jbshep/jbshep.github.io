# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Game',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('Name', models.CharField(max_length=200)),
                ('Location', models.CharField(max_length=200)),
                ('StartDate', models.DateTimeField(verbose_name='Game Start Date')),
                ('EndDate', models.DateTimeField(verbose_name='Game End Date')),
                ('Rules', models.CharField(max_length=4000)),
                ('AlertMessage', models.CharField(max_length=200)),
            ],
        ),
        migrations.CreateModel(
            name='Mission',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('StartDate', models.DateTimeField(verbose_name='Mission Start')),
                ('EndDate', models.DateTimeField(verbose_name='Mission End')),
                ('Description', models.CharField(max_length=8000)),
                ('VisibleToH', models.BooleanField(default=0)),
                ('VisibleToZ', models.BooleanField(default=0)),
                ('WinningTeam', models.IntegerField(default=0)),
                ('ResolutionMessage', models.CharField(max_length=4000)),
                ('Resolved', models.BooleanField(default=0)),
                ('GameId', models.ForeignKey(to='awesome_db.Game')),
            ],
        ),
        migrations.CreateModel(
            name='Mod',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('GameId', models.ForeignKey(to='awesome_db.Game')),
            ],
        ),
        migrations.CreateModel(
            name='Player',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('IsMod', models.BooleanField(default=0)),
                ('GameId', models.ForeignKey(to='awesome_db.Game')),
            ],
        ),
        migrations.CreateModel(
            name='PlayerType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('Name', models.CharField(max_length=200)),
                ('Description', models.CharField(max_length=4000)),
                ('TeamId', models.IntegerField(default=1)),
                ('GameId', models.ForeignKey(to='awesome_db.Game')),
            ],
        ),
        migrations.CreateModel(
            name='Tag',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('TaggedTime', models.DateTimeField(verbose_name='Tagged Time')),
                ('GameId', models.ForeignKey(to='awesome_db.Game')),
                ('tagged', models.ForeignKey(to='awesome_db.Player', related_name='tagged')),
                ('tagger', models.ForeignKey(to='awesome_db.Player', related_name='tagger')),
            ],
        ),
        migrations.CreateModel(
            name='TagType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('GameId', models.ForeignKey(to='awesome_db.Game')),
                ('TaggedType', models.ForeignKey(to='awesome_db.PlayerType', related_name='tagged')),
                ('TaggerType', models.ForeignKey(to='awesome_db.PlayerType', related_name='tagger')),
                ('TurnsToType', models.ForeignKey(to='awesome_db.PlayerType', related_name='turnsTo')),
            ],
        ),
        migrations.CreateModel(
            name='UpdateBoard',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('SentDate', models.DateTimeField(verbose_name='Sent')),
                ('SentByPlayerTeam', models.IntegerField(default=1)),
                ('VisibleToZ', models.BooleanField(default=0)),
                ('VisibleToH', models.BooleanField(default=0)),
                ('MessageType', models.IntegerField(default=0)),
                ('Message', models.CharField(max_length=2000)),
                ('GameId', models.ForeignKey(to='awesome_db.Game')),
            ],
        ),
        migrations.CreateModel(
            name='UserAccount',
            fields=[
                ('id', models.AutoField(verbose_name='ID', auto_created=True, primary_key=True, serialize=False)),
                ('UserName', models.CharField(max_length=200)),
                ('FullName', models.CharField(max_length=200)),
                ('Email', models.CharField(max_length=200)),
                ('authId', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.AddField(
            model_name='updateboard',
            name='SenderId',
            field=models.ForeignKey(to='awesome_db.UserAccount'),
        ),
        migrations.AddField(
            model_name='player',
            name='PlayerTypeId',
            field=models.ForeignKey(to='awesome_db.PlayerType'),
        ),
        migrations.AddField(
            model_name='player',
            name='UserId',
            field=models.ForeignKey(to='awesome_db.UserAccount'),
        ),
        migrations.AddField(
            model_name='mod',
            name='ModId',
            field=models.ForeignKey(to='awesome_db.UserAccount'),
        ),
    ]
