from django.conf.urls import url
from django.contrib.auth import views
#from django.views.generic.edit import CreateView
#from django.contrib.auth.forms import UserCreationForm

from . import views

urlpatterns = [
	url(r'^$', views.index, name='index'),
	url(r'^newuser/$', views.newuser, name='newuser'),
	url(r'^login/$', views.mylogin, name='login'),
	url(r'^home/$', views.home, name='home'),
	url(r'^games/$', views.games, name='games'),
	url(r'^creategame/$', views.create_game_form, name='create_game_form'),
]
