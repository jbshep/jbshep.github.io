from django.contrib.auth.models import User
from django.forms import ModelForm
from .models import Game, Player
class UserForm(ModelForm):
	class Meta:
		model = User
		fields = ('username','email','password')

# GameForm is the form used to pass the data from the html page via post to the views.
class GameForm(ModelForm):
	class Meta:
		model = Game
		#Alert message has been left out due to it being set later by the mods of the game as needed.
		fields = ('Name','Location','Rules','StartDate','EndDate')
'''
class PlayerForm(ModelForm):
	class Meta:
		model = Player
		fields = ('Game')
'''

