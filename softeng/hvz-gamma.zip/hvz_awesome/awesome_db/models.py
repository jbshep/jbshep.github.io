from django.db import models
from django.contrib.auth.models import User

#class UserAccount(models.Model):
#	authId = models.ForeignKey(User)
#	UserName = models.CharField(max_length=200)
#	FullName = models.CharField(max_length=200)
#	Email = models.CharField(max_length=200)
#	def __str__(self):
#		return self.UserName

class Game(models.Model):
	Name = models.CharField(max_length=200)
	Location = models.CharField(max_length=200)
	StartDate = models.DateTimeField('Game Start Date')
	EndDate = models.DateTimeField('Game End Date')
	Rules = models.CharField(max_length=4000)
	AlertMessage = models.CharField(max_length=200)
	def __str__(self):
		return self.Name

class PlayerType(models.Model):
	GameId = models.ForeignKey(Game)
	Name = models.CharField(max_length=200)
	Description = models.CharField(max_length=4000)
	TeamId = models.IntegerField(default= 1)
	def __str__(self):
		return self.Name

class Player(models.Model):
	GameId = models.ForeignKey(Game)
	UserId = models.ForeignKey(User)
	PlayerTypeId = models.ForeignKey(PlayerType)
	IsMod = models.BooleanField(default=0)
	def __str__(self):
		return self.UserId;

class Tag(models.Model):
	GameId = models.ForeignKey(Game)
	tagger = models.ForeignKey(Player,related_name='tagger')
	tagged = models.ForeignKey(Player,related_name='tagged')
	TaggedTime = models.DateTimeField('Tagged Time')
	def __str__(self):
		return (self.tagger+" tagged "+ self.tagged)
		
class TagType(models.Model):
	GameId = models.ForeignKey(Game)
	TaggerType = models.ForeignKey(PlayerType,related_name='tagger')
	TaggedType = models.ForeignKey(PlayerType,related_name='tagged')
	TurnsToType = models.ForeignKey(PlayerType,related_name='turnsTo')
	def __str__(self):
		return self.TurnsToType;

class Mod(models.Model):
	GameId = models.ForeignKey(Game)
	ModId = models.ForeignKey(User)
	def __str__(self):
		return self.ModId

class UpdateBoard(models.Model):
	GameId = models.ForeignKey(Game)
	SentDate = models.DateTimeField('Sent')
	SenderId = models.ForeignKey(User)
	SentByPlayerTeam = models.IntegerField(default= 1)
	VisibleToZ = models.BooleanField(default=0)
	VisibleToH = models.BooleanField(default=0)
	MessageType = models.IntegerField(default = 0)
	Message= models.CharField(max_length=2000)
	def __str__(self):
		return self.Message
	
class Mission(models.Model):
	GameId = models.ForeignKey(Game)
	StartDate = models.DateTimeField('Mission Start')
	EndDate = models.DateTimeField('Mission End')
	Description = models.CharField(max_length=8000)
	VisibleToH = models.BooleanField(default=0)
	VisibleToZ = models.BooleanField(default=0)
	WinningTeam = models.IntegerField(default = 0)
	ResolutionMessage = models.CharField(max_length=4000)
	Resolved = models.BooleanField(default=0)
	def __str__(self):
		return self.Description
