#Instillation Instructions for HVZ-GAMMA
<br>
##Table of Contents

<ol>
	<li>Introduction
	<li>Git Hub Instructions
	<li>Python Installation
	<li>Database installation
	<li>Django Installation / Settings Manipulation
	<li>Running the server
</ol>

###Section 1 Introduction

This Readme file will give you all the steps needed to get the HVZ-Gammma site up and running in its current form. Make sure not to skip any steps as all are needed to get the database and the code to work together and to properly display the pages of the site.

###Section 2 - Git hub Instructions

The first thing that needs to be done to install this application is to make a Git hub account. 
This can be done at the following address:

[https://github.com/join](https://github.com/join)

Depending on the environment in which you are using the HVZ-GAMMA site you will change how you install the 
application. On windows you will need to download the git bash application at this address:


[https://git-for-windows.github.io/](https://git-for-windows.github.io/)

	Note: Mac and Linux users will use the terminal applications that are built into their operating system

After installing you will now be able to clone the repository to your computer. After downloading git bash double run it to 
and move to the location on your computer that you would like to place the hvz site. The same thing will go for Linux and Mac 
users. To clone it use the command `git clone` followed by the URL of the repository that you are wishing to 
download.
###Section 3 - Python Installation

To download the necessary python 3.4.3 installation go to this URL and download it.

[https://www.python.org/downloads/](https://www.python.org/downloads/)

Once the installer is downloaded run it and install it to your specifications.  

###Section 4 - Database Installation

Now that you have the site on your requested computer or server and have python 3.4 installed, the next step is to download the mysql database engine that the site uses. This can be done at the following URL:

[http://dev.mysql.com/downloads/installer/](http://dev.mysql.com/downloads/installer/)

Once there you will need to download and run the installer. the installer can be a little hard to handle the first time walking through so take your time when walking through it.

After you have successfully installed the database engine you will need to add the actual database to your computer. To do this you will need to find the mysql command line client on windows or use the terminal application if on mac or Linux. Once you are at one of those spots log into to your db engine. After that run the command 'create DATABASE hvzawesome;'. 



###Section 5 - Django Installation / Settings Manipulation

To make it so that the Database will work with the Django code you will have to change the settings.py page in the hvz_awesome folder. In the database section of the settings.py change the password to the one you setup with your database. after your have done this you you will need to install django so that you can run the commands to make the server run. Inside gitbash you will need to run the command 'pip install django'. If this comes back with "pip command not found" you will need to add pip to your system path.

After you have installed django you will need to run a series of commands to make it so mysql and django communicate. These commands will be run from the main folder of your hvz site, the one that has manage.py in it. The steps are:

<ol>
	<li>pip install git+https://github.com/multiplay/mysql-connector-python –upgrade
	<li>python manage.py makemigrations hvz_db
	<li>python manage.py sqlmigrate hvz_db 0001
	<li>python manage.py migrate
</ol>

###Section 6 - Running the server

You should be able to at this point go to the folder containing manage.py in gitbash and run the command 'python manage.py runserver' and go to the ip address listed when the command is running to view the log-in page of your now functional HVZ site.