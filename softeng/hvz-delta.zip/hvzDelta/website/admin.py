from django.contrib import admin
from .models import Player, Kill, Post, Notification, Mission

admin.site.register(Player)
admin.site.register(Kill)
admin.site.register(Post)
admin.site.register(Notification)
admin.site.register(Mission)
# Register your models here.
