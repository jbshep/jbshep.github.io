from django.test import TestCase
from django.db import IntegrityError
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.models import *
from website.models import *

class KillTestCase(TestCase):
    #setUP creates database entries to run tests against.
    def setUp(self):
        u=User.objects.create(
            username="ColinBro",
            first_name="Colin",
            last_name="Hansen",
            email="hanscol@bvu.edu",
            password="seahorses"
        )
        p=Player.objects.create(
            user_id=u.id,
            killcode="abcdef1234567890"
        )
    #testValidKill tests creating a new user with a valid killcode.
    def testValidKill(self):
        p=User.objects.create(
            username="ColinBro2",
            first_name="Colin",
            last_name="Hansen",
            email="hanscol1@bvu.edu",
            password="megahorn"
        )
        newUser=Player.objects.create(
            user_id=p.id,
            killcode="1234567890abcded"
        )
        self.assertEqual(type(newUser.id),long)

    #testDuplicateKill tests if a user can be added to the database if their killcode is the same.
    #The answer is no. just no.
    def testDuplicateKill(self):
        p=User.objects.create(
            username="ColinBro2",
            first_name="Colin",
            last_name="Hansen",
            email="hanscol1@bvu.edu",
            password="megahorn"
        )
        newUser=Player(
            user_id=p.id,
            killcode="abcdef1234567890"
        )
        with self.assertRaises(IntegrityError):
            newUser.save()
    #testInvalidKillGrab checks to see if a player can submit a killcode
    #that isn't in the database.
    def testInvalidKillGrab(self):
        with self.assertRaises(ObjectDoesNotExist):
            user=Player.objects.get(killcode="abcdef1234567899")
    #testValidKillGrab makes sure you can score with a valid killcode.
    def testValidKillGrab(self):
        user=Player.objects.filter(killcode="abcdef1234567890")
        self.assertEqual(len(user),1)
