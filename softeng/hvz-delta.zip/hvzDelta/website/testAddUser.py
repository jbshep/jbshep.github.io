from django.test import TestCase
from website.models import *
from django.contrib.auth.models import *
from django.db import IntegrityError
class PlayerTestCase(TestCase):
    #setUp creates database enteries to run tests against.
    def setUp(self):
        u=User.objects.create(
            username="ColinBro",
            first_name="Colin",
            last_name="Hansen",
            email="hanscol@bvu.edu",
            password="seahorses"
        )
        Player.objects.create(
            user_id=u.id,
            killcode="abcdef1234567890"
        )
    #test_add_user() tests to see if you can successfully add a user
    #with the same first and last name.
    def test_add_user(self):
        p=User.objects.create(
            username="ColinBro2",
            first_name="Colin",
            last_name="Hansen",
            email="hanscol1@bvu.edu",
            password="megahorn"
        )
        newUser=Player.objects.create(
            user_id=p.id,
            killcode="1234567890abcded"

        )
        self.assertEqual(type(newUser.id),long)
    #test_add_with_same_killcode() tests to make sure that
    #two users cannot have the same killcode.
    def test_add_with_same_killcode(self):
        p2=User.objects.create(
            username="newGuy",
            first_name="Jake",
            last_name="Coleman",
            email="colmjak@bvu.edu",
            password="seapony"
        )
        newUser2=Player(
            user_id=p2.id,
            killcode="abcdef1234567890"
        )
        with self.assertRaises(IntegrityError):
            newUser2.save()
    #test_add_with_same_email() tests to see if two users
    #can have the same email address. They should be able to...
    def test_add_with_same_email(self):
        p2=User.objects.create(
            username="Coolio",
            first_name="Frank",
            last_name="Morgans",
            email="hanscol@bvu.edu",
            password="greedyGuy"
        )
        newUser2=Player(
            user_id=p2.id,
            killcode="159632478abcdef"
        )
        newUser2.save()
        numUsers=User.objects.filter(email="hanscol@bvu.edu")
        #print(numUsers)
        self.assertEqual(len(numUsers),2)
        
    #test_add_with_same_username() tests to make sure that two users
    #cannot have the same username.
    def test_add_with_same_username(self):
        p2=User(
            username="ColinBro",
            first_name="Guy",
            last_name="Fiery",
            email="hanscol@bvu.edu",
            password="cheetos"
        )
        newUser2=Player(
            user_id=p2.id,
            killcode="321644789abcdef"
        )
        with self.assertRaises(IntegrityError):
            newUser2.save()




