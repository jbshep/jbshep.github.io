from django.shortcuts import render
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse, HttpResponseRedirect
from website.models import Player, Kill, Post, Notification, Mission
from django.contrib.auth.models import *
import random

"""
-The createKillcode function will create a random killcode, and then check the database to see if it is already being used. 
-If it is, then it will call itself recursively, but if it doesn't then it will return a valid killcode to use.
"""

def createKillcode():  
    _kc =  ''.join(random.choice('0123456789ABCDEF') for i in range(16))
    if _kc in Player.objects.filter(killcode=_kc):
	createKillcode()
    else:
    	return _kc

def index(request):
    print("index")
    return render(request, 'index.html',{'playertype':"ZOMBIE", 'zombiecount':"12",'humancount':"17" })

def logIn(request):
    return render(request, 'logIn.html')

def Lindex(request):
    return render(request, 'Lindex.html')

def kills(request):
    return render(request, 'kills.html')

def register(request):
    return render(request, 'register.html')

@csrf_exempt
def doLogout(request):
    if 'userData' in request.session:
        logout(request)
	request.session['userData'] = False
	request.session['logout'] = "You have succesfully logged out"
	return HttpResponseRedirect('logIn')
 

"""
-The doLogin function takes in the request object as its parameters, 
and as its output it will redirect the user back to the index page if they have logged in correctly, 
after having validated the user using Django's authorization system.
-If the user does not log in correctly, then an error variable labeled 'badLogin' will be passed to the session object, 
which will be passed from the server side to the client side, and the user will be redirected back to the login page.
-The client will check for this variable, and display it if necessary. The server will dispose of the variable if it has already been used.
"""

@csrf_exempt
def doLogin(request):
    request.session.set_expiry(0)    
    
    if 'badLogin' in request.session:
	del request.session['badLogin']

    if 'userData' in request.session:
	del request.session['userData']
 
    if 'logout' in request.session:
	del request.session['logout']
   
    if request.method == 'POST':
        _username = request.POST.get('username')
	_password = request.POST.get('password')
	user = authenticate(username=_username, password=_password)
        if user:
            request.session['userData'] = True
            login(request,user)
	    return HttpResponseRedirect('/')
        else:
            badLogin = "Invalid Login!"
            request.session['badLogin'] = badLogin
	    return HttpResponseRedirect('logIn')

"""
-The doRegistration function takes in a request object as its parameter,
and as its output it will create a new Player in the database, and redirect the user to the Login page.
-If the username is already taken, or the password and the pwd_confirm do not match, then a redirect back to the page
with the error variables will occur.
-The client will check for this variable, and display it if necessary. The server will dispose of the variable if it has already been used.
"""

@csrf_exempt            
def doRegistration(request):
    request.session.set_expiry(0)    

    if 'exist' in request.session:
      	del request.session['exist']
    
    if 'pwd' in request.session:
      	del request.session['pwd']

    if request.method == 'POST':
        _email = request.POST.get('email')
        _username = request.POST.get('username')
        _first_name = request.POST.get('first_name')
        _last_name = request.POST.get('last_name')
        _password = request.POST.get('password')
        pwd_confirm = request.POST.get('pwd_confirm') 
 	if _password != pwd_confirm:
	    pwd = "Passwords do not match"
	    request.session['pwd'] = pwd
	    return HttpResponseRedirect('register')
  	else:
          try:
    	     p = User.objects.get(username=_username)
	     exist = "Username is taken, try another username"
	     request.session['exist'] = exist
	     return HttpResponseRedirect('register')
	  except ObjectDoesNotExist:
	     _killcode = createKillcode()
   	     u=User(username=_username,first_name=_first_name,last_name=_last_name,email=_email,password=_password)
	     u.set_password(u.password)
    	     u.save()
	     p=Player(user_id=u.id,killcode=_killcode)
	     p.save()
	     return HttpResponseRedirect('logIn')
