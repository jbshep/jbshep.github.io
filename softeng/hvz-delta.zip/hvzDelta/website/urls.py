from django.conf.urls import url, include
from website import views
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', views.index, name='index'),
    url(r'^logIn', views.logIn, name='logIn'),
    url(r'^Lindex', views.Lindex, name='Lindex'),
    url(r'^register', views.register, name='register'),
    url(r'^doLogin', views.doLogin, name='doLogin'),
    url(r'^kills', views.kills, name='kills'),	
    url(r'^doRegistration', views.doRegistration, name='doRegistration'),
    url(r'^doLogout', views.doLogout, name='doLogout'),
]
