from django.contrib.auth.models import User
from django.db import models

class Player(models.Model):
    user=models.OneToOneField(User)
    killcode=models.CharField(max_length=16,unique=True)
    human=models.BooleanField(default=True)

class Kill(models.Model):
    zombie=models.ForeignKey('Player',related_name='+')
    killcode=models.ForeignKey('Player',related_name='+')
    timestamp=models.DateTimeField(auto_now_add=True)

class Post(models.Model):
    content=models.CharField(max_length=256)
    title=models.CharField(max_length=64)
    timestamp=models.DateTimeField(auto_now_add=True)
    poster=models.ForeignKey('Player',related_name='+')

class Notification(models.Model):
    content=models.CharField(max_length=256)
    title=models.CharField(max_length=64,blank=True)
    timestamp=models.DateTimeField(auto_now_add=True)

class Mission(models.Model):
    content=models.CharField(max_length=1024)
    location=models.CharField(max_length=64)
    human=models.BooleanField()
    current=models.BooleanField()
