# HVZ-Delta

THIS FOR INSTALLATION ON A LINUX VM. <br>
Things to Install:
- apt-get install python-pip
- pip install Django==1.8.5
- apt-get install mysql-client-5.6 mysql-server-5.6
  + user=root 
  + password=delta
- apt-get install python-mysqldb

Instructions to get the project running:
- mysql -uroot -pdelta
    + CREATE DATABASE hvz_db;
    + exit;
- git clone https://github.com/jbshep/hvz-delta
- cd /hvz-delta/hvzDelta/
- ./manage.py makemigrations
- ./manage.py migrate
- ./manage.py runserver %IP%:%PORT%

At this point the server should be up and running.Open up an Internet browser and go type %IP%:%PORT% into the address bar to go to the website.

NOTES:
DB superuser for Django is:
  delta
<br>password:
  delta
